import React from "react";

function Home() {
    return (
        <main>
            <h1>MealDB Explorer</h1>
            <p>Search and explore meals from TheMealDB API.</p>
        </main>
    );
}

export default Home;